class AssetsPath {
  AssetsPath._();
  static String craftyBayLogoSVG = 'assets/images/logo.svg';
  static const String craftyBayNavLogoSVG = 'assets/images/logo_nav.svg';
}