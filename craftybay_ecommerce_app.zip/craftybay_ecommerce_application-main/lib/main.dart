import 'package:craftybay_ecommerce_application/application/app.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const CraftyBay());
}