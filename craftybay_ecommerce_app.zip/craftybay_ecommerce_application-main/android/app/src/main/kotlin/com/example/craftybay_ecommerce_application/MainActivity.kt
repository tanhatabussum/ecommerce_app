package com.example.craftybay_ecommerce_application

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
